# Insightface 얼굴 로그인 + 고객 이탈 예측 Streamlit 앱 (실습용)

앱은 먼저 얼굴을 등록하고, 등록된 얼굴과 로그인 얼굴을 비교하여 인증함 (로그인 인증)
얼굴 로그인에 성공한 사용자만 고객 이탈 예측 서비스를 사용할 수 있음

# 1. 프로젝트 구조
face_churn_app/
    |- app.py       # Streamlit 메인 실행 파일
    |- app/
    |   |- ui.py        # Streamlit  로그인세션/로그아웃, 화면구성 제공 
    |-  requirements.txt    # 설치할 패키지 목록
    |- README.md    # 프로젝트 설명 문서

# 앱 실행
streamlit run app.py

