# Streamlit + OpenCV + InsightFace 얼굴 로그인 + 고객 이탈 예측 메인 스크립트

# Streamlit은 웹 화면 실행과 세션 상태 관리를 담당합니다.
import streamlit as st

# UI 화면 구성 함수만 가져옵니다.
from app.ui import (
    init_session_state,
    render_churn_form,
    render_churn_result,
    render_login_ui,
    render_page_header,
    render_register_ui,
    render_sidebar,
)


# 얼굴 인증 임계값 화면 테스트용 기본값입니다.
DEFAULT_SIMILARITY_THRESHOLD = 0.45


# Streamlit 브라우저 탭 제목, 아이콘, 화면 폭을 설정합니다.
st.set_page_config(
    page_title="UI Test - Face Login + Churn Prediction",
    page_icon="🧪",
    layout="wide",
)


# 로그인 상태, 사용자 ID, 얼굴 점수 세션 값을 초기화합니다.
init_session_state()


# 앱 상단 제목과 설명 문구를 출력합니다.
render_page_header()


# 사이드바를 출력하고 사용자가 선택한 얼굴 인증 임계값을 받습니다.
threshold = render_sidebar(default_threshold=DEFAULT_SIMILARITY_THRESHOLD)


# UI 테스트 모드 안내 메시지를 출력합니다.
st.info(
    "현재는 UI 렌더링 확인 모드입니다. "
    "얼굴 인식 모델과 고객 이탈 예측 모델은 실행하지 않습니다."
)


# 화면 전환 테스트를 위한 체크박스입니다.
force_login = st.checkbox(
    "테스트용 로그인 상태로 전환",
    value=st.session_state.logged_in,
)


# 체크박스 값에 따라 세션 로그인 상태를 임시 변경합니다.
st.session_state.logged_in = force_login


# 로그인 전 화면 테스트입니다.
if not st.session_state.logged_in:
    # 얼굴 등록 탭과 얼굴 로그인 탭을 생성합니다.
    register_tab, login_tab = st.tabs(["1. 얼굴 등록 UI", "2. 얼굴 로그인 UI"])

    # 얼굴 등록 UI 렌더링을 확인합니다.
    with register_tab:
        # 등록 UI를 출력하고 입력값을 받습니다.
        register_clicked, user_id, selected_file = render_register_ui()

        # 등록 버튼 클릭 시 실제 등록 대신 테스트 메시지만 출력합니다.
        if register_clicked:
            st.success("얼굴 등록 버튼 클릭 확인")
            st.write("입력한 사용자 ID:", user_id)
            st.write("선택된 파일 여부:", selected_file is not None)

    # 얼굴 로그인 UI 렌더링을 확인합니다.
    with login_tab:
        # 로그인 UI를 출력하고 입력값을 받습니다.
        login_clicked, login_selected_file = render_login_ui()

        # 로그인 버튼 클릭 시 실제 인증 대신 테스트 메시지만 출력합니다.
        if login_clicked:
            st.success("얼굴 로그인 버튼 클릭 확인")
            st.write("선택된 파일 여부:", login_selected_file is not None)
            st.write("현재 임계값:", threshold)


# 로그인 후 화면 테스트입니다.
else:
    # 고객 이탈 예측 입력 폼을 출력합니다.
    submitted, values = render_churn_form()

    # 예측 버튼 클릭 시 실제 모델 대신 샘플 결과를 출력합니다.
    if submitted:
        # 모델 실행 없이 화면 표시만 확인하기 위한 더미 결과입니다.
        dummy_result = {
            "prediction": 1,
            "label": "이탈 가능성 높음",
            "churn_probability": 0.73,
        }

        # 입력값 확인용으로 폼 데이터를 출력합니다.
        st.write("입력값 확인:", values)

        # 예측 결과 UI를 출력합니다.
        render_churn_result(dummy_result)
